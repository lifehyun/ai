package dao;

import java.util.ArrayList;
import dto.Product;

public class ProductRepository {
	
	private ArrayList<Product> listOfProducts = new ArrayList<Product>(); //배열을 객체화.
	
	public ProductRepository() { // 상품값을 넣어준다.
	Product phone = new Product("P1234", "iPhone 6s", 800000);
	phone.setDescription("4.-7inch, 1334X750 Renina HD display,8megapixel iSight Camera");
	phone.setCategorty("Smart Phone");
	phone.setManufacturer("Apple");
	phone.setUnitPrice(800000);
	phone.setCondition("New");
	phone.setFilename("P1234.png");
	
	Product notebook = new Product("P1235", "LG PC 그램", 1500000);
	notebook.setDescription("13.3-inch, IPS LED display, 5rd Generation Intel Core processor");
	notebook.setCategorty("NoteBook");
	notebook.setManufacturer("LG");
	notebook.setUnitPrice(1500000);
	notebook.setCondition("Refurbished");
	notebook.setFilename("P1235.png");
	
	Product tablet = new Product("P1236", "Galaxy Tab", 900000);
	tablet.setDescription("221.8*125.6*6.6mm, Super AMOLED display, Octa-Core processor");
	tablet.setCategorty("Tablet");
	tablet.setManufacturer("Samsung");
	tablet.setUnitPrice(900000);
	tablet.setCondition("Old");
	tablet.setFilename("P1236.png");
	
	//배열에 객체화한걸 추가한다.
	listOfProducts.add(phone); //0열
	listOfProducts.add(notebook);//1열
	listOfProducts.add(tablet);//2열

	}
	
	public ArrayList<Product> getAllProducts(){ //주소를 리턴해준다.
		return listOfProducts;
	}
	
	// 상품 상세 정보를 가져오는 메소드
	public Product getProductById(String productId) {
		Product productById = null;
		for(int i=0; i<= listOfProducts.size(); i++) {
			Product product = listOfProducts.get(i);
			if(product != null && product.getProductId() != null && product.getProductId().equals(productId)) {
				productById = product;
				break;
			}
		}
		return productById; 
	}
		
	private static ProductRepository instance = new ProductRepository(); // ProductRepository인 자기를 instance로 대입 해서 주소를 가져온다. 
	
	public static ProductRepository getInstance() {
		return instance;
	}
	
	// 상품의 내용을 넣어둔 배열리스트에 추가한다
	public void addProduct(Product product) {
		listOfProducts.add(product);
	}
	
}



